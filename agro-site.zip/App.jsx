import { useState, useEffect, useRef } from "react";
import "./App.css";

const NAV_LINKS = [
  { id: "home", label: "Главная" },
  { id: "about", label: "О нас" },
  { id: "products", label: "Продукция" },
  { id: "services", label: "Услуги" },
  { id: "stats", label: "Показатели" },
  { id: "contact", label: "Контакты" },
];

const PRODUCTS = [
  { icon: "🌾", name: "Пшеница", desc: "Озимая и яровая пшеница высшего класса. Урожайность до 65 ц/га.", tag: "Зерновые" },
  { icon: "🌽", name: "Кукуруза", desc: "Гибридные сорта кукурузы для зерна и силоса. Влагостойкие культуры.", tag: "Зерновые" },
  { icon: "🌻", name: "Подсолнечник", desc: "Высокомасличные сорта. Содержание масла до 52%. Безгербицидные технологии.", tag: "Масличные" },
  { icon: "🥕", name: "Овощи", desc: "Морковь, свёкла, картофель. Выращивание по стандартам ЕС.", tag: "Овощи" },
  { icon: "🍎", name: "Яблоки", desc: "Интенсивный сад: Голден, Гала, Фуджи. Хранение до 10 месяцев.", tag: "Сад" },
  { icon: "🫘", name: "Соя", desc: "Высокобелковые сорта сои. Без ГМО, сертификаты органического производства.", tag: "Масличные" },
];

const SERVICES = [
  { icon: "🚜", title: "Обработка полей", desc: "Вспашка, культивация, посев с применением GPS-навигации и точного земледелия." },
  { icon: "💧", title: "Ирригация", desc: "Современные системы капельного и дождевального полива. Экономия воды до 40%." },
  { icon: "🌱", title: "Агрономия", desc: "Подбор культур, анализ почвы, разработка севооборота и схем питания растений." },
  { icon: "📦", title: "Хранение", desc: "Элеваторы и склады на 15 000 тонн. Контроль температуры и влажности." },
  { icon: "🔬", title: "Лаборатория", desc: "Контроль качества зерна, анализ почвы, фитосанитарный мониторинг." },
  { icon: "🚛", title: "Логистика", desc: "Собственный автопарк для доставки. Прямые контракты с переработчиками." },
];

const STATS = [
  { value: 12500, suffix: " га", label: "Обрабатываемых земель" },
  { value: 28, suffix: " лет", label: "Опыта работы" },
  { value: 95, suffix: "%", label: "Качество продукции" },
  { value: 340, suffix: "+", label: "Постоянных клиентов" },
];

function useCountUp(target, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime = null;
    const step = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);
  return count;
}

function StatCard({ value, suffix, label, animate }) {
  const count = useCountUp(value, 1800, animate);
  return (
    <div className="stat-card">
      <div className="stat-value">{count}{suffix}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

function Navbar({ active }) {
  const [open, setOpen] = useState(false);
  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setOpen(false);
  };
  return (
    <nav className="navbar">
      <div className="nav-brand" onClick={() => scrollTo("home")}>
        <span className="nav-logo">🌿</span>
        <span className="nav-title">АгроПром</span>
      </div>
      <button className="burger" onClick={() => setOpen(!open)} aria-label="Меню">
        <span></span><span></span><span></span>
      </button>
      <ul className={`nav-links ${open ? "open" : ""}`}>
        {NAV_LINKS.map((l) => (
          <li key={l.id}>
            <button className={active === l.id ? "active" : ""} onClick={() => scrollTo(l.id)}>
              {l.label}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}

function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [sent, setSent] = useState(false);
  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = () => {
    if (!form.name || !form.email) return;
    setSent(true);
    setTimeout(() => setSent(false), 4000);
    setForm({ name: "", email: "", phone: "", message: "" });
  };
  return (
    <div className="contact-form">
      {sent && <div className="form-success">✅ Сообщение отправлено! Мы свяжемся с вами в течение 24 часов.</div>}
      <div className="form-row">
        <input name="name" value={form.name} onChange={handle} placeholder="Ваше имя *" />
        <input name="email" value={form.email} onChange={handle} placeholder="Email *" type="email" />
      </div>
      <input name="phone" value={form.phone} onChange={handle} placeholder="Телефон" type="tel" />
      <textarea name="message" value={form.message} onChange={handle} placeholder="Ваш вопрос или запрос..." rows={4} />
      <button className="btn-primary" onClick={submit}>Отправить запрос</button>
    </div>
  );
}

export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const [statsVisible, setStatsVisible] = useState(false);
  const statsRef = useRef(null);
  const [filter, setFilter] = useState("Все");

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStatsVisible(true); },
      { threshold: 0.3 }
    );
    if (statsRef.current) observer.observe(statsRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const onScroll = () => {
      for (const { id } of NAV_LINKS) {
        const el = document.getElementById(id);
        if (!el) continue;
        const rect = el.getBoundingClientRect();
        if (rect.top <= 100 && rect.bottom >= 100) { setActiveSection(id); break; }
      }
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const tags = ["Все", ...new Set(PRODUCTS.map((p) => p.tag))];
  const filtered = filter === "Все" ? PRODUCTS : PRODUCTS.filter((p) => p.tag === filter);

  return (
    <div className="app">
      <Navbar active={activeSection} />

      {/* HERO */}
      <section id="home" className="hero">
        <div className="hero-bg" />
        <div className="hero-content">
          <span className="hero-eyebrow">Сельскохозяйственное производство</span>
          <h1 className="hero-title">
            Земля как<br />
            <em>живой организм</em>
          </h1>
          <p className="hero-sub">
            Выращиваем качественную продукцию на 12 500 гектарах Краснодарского края.
            Современные агротехнологии, уважение к природе, стабильное качество.
          </p>
          <div className="hero-cta">
            <button className="btn-primary" onClick={() => document.getElementById("products")?.scrollIntoView({ behavior: "smooth" })}>
              Смотреть продукцию
            </button>
            <button className="btn-outline" onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}>
              Связаться с нами
            </button>
          </div>
        </div>
        <div className="hero-scroll-hint">↓</div>
      </section>

      {/* ABOUT */}
      <section id="about" className="section about-section">
        <div className="container about-grid">
          <div className="about-visual">
            <div className="about-img-box">
              <span className="about-big-icon">🌾</span>
              <div className="about-badge">С 1996 года</div>
            </div>
          </div>
          <div className="about-text">
            <span className="section-eyebrow">О компании</span>
            <h2>АгроПром — это больше, чем ферма</h2>
            <p>
              Мы — семейное предприятие третьего поколения с площадью угодий более 12 000 гектаров
              в Краснодарском крае. Начинали с 300 гектаров пшеницы — сегодня выращиваем 12 культур,
              содержим собственный элеватор и лабораторию контроля качества.
            </p>
            <p>
              Применяем технологии точного земледелия: дроны для мониторинга посевов, GPS-навигацию,
              цифровые карты полей и систему управления агрономическими данными.
            </p>
            <div className="about-values">
              {["🌱 Устойчивое земледелие", "🔬 Наука в основе", "🤝 Честные партнёрства"].map((v) => (
                <span key={v} className="value-chip">{v}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PRODUCTS */}
      <section id="products" className="section products-section">
        <div className="container">
          <span className="section-eyebrow">Что мы выращиваем</span>
          <h2 className="section-title">Наша продукция</h2>
          <div className="filter-bar">
            {tags.map((t) => (
              <button key={t} className={`filter-btn ${filter === t ? "active" : ""}`} onClick={() => setFilter(t)}>
                {t}
              </button>
            ))}
          </div>
          <div className="products-grid">
            {filtered.map((p) => (
              <div key={p.name} className="product-card">
                <div className="product-icon">{p.icon}</div>
                <span className="product-tag">{p.tag}</span>
                <h3>{p.name}</h3>
                <p>{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="section services-section">
        <div className="container">
          <span className="section-eyebrow">Что мы предлагаем</span>
          <h2 className="section-title">Услуги</h2>
          <div className="services-grid">
            {SERVICES.map((s) => (
              <div key={s.title} className="service-card">
                <div className="service-icon">{s.icon}</div>
                <h3>{s.title}</h3>
                <p>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* STATS */}
      <section id="stats" className="section stats-section" ref={statsRef}>
        <div className="container">
          <span className="section-eyebrow">Цифры говорят сами</span>
          <h2 className="section-title">Наши показатели</h2>
          <div className="stats-grid">
            {STATS.map((s) => (
              <StatCard key={s.label} {...s} animate={statsVisible} />
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="section contact-section">
        <div className="container contact-grid">
          <div className="contact-info">
            <span className="section-eyebrow">Свяжитесь с нами</span>
            <h2>Готовы к сотрудничеству?</h2>
            <p>Оставьте заявку — наш агроном свяжется с вами в течение рабочего дня.</p>
            <div className="contact-details">
              <div className="contact-item"><span>📍</span> Краснодарский край, ст. Динская, ул. Полевая 12</div>
              <div className="contact-item"><span>📞</span> +7 (861) 234-56-78</div>
              <div className="contact-item"><span>✉️</span> info@agroprom-kuban.ru</div>
              <div className="contact-item"><span>🕐</span> Пн–Пт: 8:00–18:00</div>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>

      <footer className="footer">
        <div className="container footer-inner">
          <div className="footer-brand">
            <span>🌿</span> АгроПром © 2026
          </div>
          <div className="footer-links">
            {NAV_LINKS.map((l) => (
              <button key={l.id} onClick={() => document.getElementById(l.id)?.scrollIntoView({ behavior: "smooth" })}>
                {l.label}
              </button>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
